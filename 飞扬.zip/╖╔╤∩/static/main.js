﻿$(function () {

    const ap = new APlayer({
        container: document.getElementById('aplayer'),
        narrow: false,
        autoplay: true,
        showlrc: true,
        audio: [
            {
                name: 'WHITE ALBUM',
                artist: '平野綾',
                theme: '#ebd0c2',
                url: 'http://api.bzqll.com/music/netease/url?id=32303030&key=579621905',
                cover: 'http://api.bzqll.com/music/netease/pic?id=32303030&key=579621905',
                lrc: '[by:樱与微风的化学反应]\n' +
                    '[00:05.77]...\n' +
                    '[00:28.79]すれ哌う毎日が 増えてゆくけれど\n' +
                    '[00:38.30]お互いの気持ちはいつも 側にいるよ\n' +
                    '[00:47.86]ふたり会えなくても 平気だなんて\n' +
                    '[00:57.44]強がり言うけど 溜め息まじりね\n' +
                    '[01:07.25]過ぎてゆく季節に 置いてきた宝物\n' +
                    '[01:16.80]大切なピ┅スの欠けた パズルだね\n' +
                    '[01:26.48]白い雪が街に 優しく積もるように\n' +
                    '[01:35.92]アルバムの空白を全部 埋めてしまおう\n' +
                    '[01:49.13]...\n' +
                    '[01:55.12]降り積もるさびしさに 負けてしまいそうで\n' +
                    '[02:04.85]ただひとり 不安な日々を過ごしてても\n' +
                    '[02:14.39]大丈夫だよって 肩をたたいて\n' +
                    '[02:23.78]あなたは笑顔で 元気をくれるね\n' +
                    '[02:33.46]たとえ離れていても その言葉があるから\n' +
                    '[02:43.06]心から幸せと言える 不思議だね\n' +
                    '[02:52.78]淡い雪がわたしの ひそかな想い込めて\n' +
                    '[03:02.26]純白のアルバムの ペ┅ジ染めてくれる\n' +
                    '[03:15.71]...\n' +
                    '[03:31.23]過ぎてゆく季節に 置いてきた宝物\n' +
                    '[03:40.74]大切なピ┅スの欠けた パズルだね\n' +
                    '[03:50.35]白い雪が街に 優しく積もるように\n' +
                    '[03:59.96]アルバムの空白を全部 埋めてしまおう\n' +
                    '[04:14.08]...'
            }
        ]
    });
    let music = [];
    let data = {
        input: '独家记忆',
        filter: 'name',
        type: 'netease',
        page: 1,
    };

    function getMusic(data) {
        $.ajax({
            url: '/getMusic',
            type: 'POST',
            data: {
                data: JSON.stringify(data),
            },
            dataType: 'json',
            beforeSend: function () {
                $("#loading").fadeIn(200);
            },
            complete: function () {
                $("#loading").fadeOut(200);
            },

            success: function (res) {
                ap.list.clear();
                console.log(0);
                $('.download').attr('href', res.data[0].url);
                $('.download').attr('download', res.data[0].title);


                for (let i = 0; i < 10; i++) {
                    music[i] = {};
                    music[i].id = res.data[i].songid;
                    music[i].name = res.data[i].title;
                    music[i].singer = res.data[i].author;
                    music[i].pic = res.data[i].pic;
                    music[i].url = res.data[i].url;
                    music[i].lrc = res.data[i].lrc;
                    ap.list.add([{
                        name: music[i].name,
                        artist: music[i].singer,
                        url: music[i].url,
                        cover: music[i].pic,
                        lrc: music[i].lrc,
                        theme: '#ebd0c2'
                    }]);
                    ap.play();

                }


            },
            error: function (res) {
                console.log(1);
            }

        })
    }

    function updateMessage(i) {
        $('.download').attr('href', music[i].url);
        $('.download').attr('download', music[i].name);
    }

    $(".aplayer-list ol").on("click", "li", function () {      //只需要找到你点击的是哪个ul里面的就行
        var index = $(this).index();
        updateMessage(index);
    });
    $(".submit").click(function () {
        var searchname = $(".text").val();
        data.input = searchname;
        var val = $("input[name='music-select']:checked").val();
        if (val == 'netease') {
            data.type = 'netease';
            getMusic(data);
        } else if (val == 'qq') {
            data.type = 'qq';
            getMusic(data);
        } else if (val == 'kugou') {
            data.type = 'kugou';
            getMusic(data);
        } else if (val == 'kuwo') {
            data.type = 'kuwo';
            getMusic(data);
        } else if (val == 'xiami') {
            data.type = 'xiami';
            getMusic(data);
        } else if (val == 'baidu') {
            data.type = 'baidu';
            getMusic(data);
        } else if (val == '1ting') {
            data.type = '1ting';
            getMusic(data);
        } else if (val == 'migu') {
            data.type = 'migu';
            getMusic(data);
        } else if (val == 'lizhi') {
            data.type = 'lizhi';
            getMusic(data);
        } else if (val == 'qingting') {
            data.type = 'qingting';
            getMusic(data);
        } else if (val == 'ximalaya') {
            data.type = 'ximalaya';
            getMusic(data);
        } else if (val == 'kg') {
            data.type = 'kg';
            getMusic(data);
        } else if (val == '5singyc') {
            data.type = '5singyc';
            getMusic(data);
        } else if (val == '5singfc') {
            data.type = '5singfc';
            getMusic(data);
        }
    });


    //播放


    $(window).keydown(function (e) {
        var cur = e.which;
        if (cur == 13) {
            $('.search').submit();
        }
    });


// 更换皮肤

    $(function () {
        $("#skin_current").click(function () {
            $("#skin").slideToggle(300);

        });
        var $li = $("#skin li");
        $li.click(function () {
            var color = $(this).css("background");
            switchSkin(this.id, color);
        });
    });

    function switchSkin(skinName, color) {
        $("#" + skinName).addClass("selected")
            .siblings().removeClass("selected");
        $("#cssfile").attr("href", "../static/skin/" + skinName + ".css"); //设置不同皮肤
        $("#skin_current").css("background", color);
        $("#skin").slideUp(300);
    }


});

