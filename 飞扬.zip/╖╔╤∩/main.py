from flask import render_template
from flask import Flask, request
import json
import requests

def getMessage(data):
    url = 'http://music.cccyun.cc'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Host': 'music.cccyun.cc',
        'Origin': 'http://music.cccyun.cc',
        'Referer': 'http://music.cccyun.cc/?name=%E4%B8%8D%E8%A6%81%E8%AF%B4%E8%AF%9D&type=netease',
        'X-Requested-With': 'XMLHttpRequest'
    }
    response = requests.post(url, data=data, headers=headers)
    result = response.text
    return result

app=Flask(__name__,template_folder='templates',static_url_path='/static')
@app.route('/', methods=['POST','GET'])
def main():
    return render_template("main.html")

@app.route('/getMusic', methods=['POST'])
def getMusic():
    # password = request.form.get('password')
    # username = request.args.get('username')

    data = json.loads(request.form.get('data'))
    print(data)
    return getMessage(data)


if __name__ == '__main__':
    app.run()              #启动socket
