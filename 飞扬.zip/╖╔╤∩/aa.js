$(function(){
    // $.ajax({
    //     //雅虎代理url
    //     url: "https://query.yahooapis.com/v1/public/yql/",
    //     type: "POST",
    //     dataType: "jsonp",//指定数据格式
    //     data: {
    //         format: "json",//代理返回格式
    //         q: "select * from json where url=\"http://music.cccyun.cc/?name=%E4%B8%8D%E8%A6%81%E8%AF%B4%E8%AF%9D&type=netease\" "
    //
    //
    //     },
    //     // https://acg.toubiec.cn/random?return=json
    //     // dataType: "jsonp",
    //     // jsonp: "callback",
    //     //jQuery的jsonp无法正常返回数据
    //     success: function (data) {
    //         console.log(data);
    //
    //     }
    // })
    $.ajax({
                url:'main.py',
                type:'POST',
                data:JSON.stringify({'username':'js','psw':'123456789'}),
                dataType: 'json',
                success:function(res){
                    console.log(res);
                    console.log(0);

                },
                error:function (res) {
                    console.log(res);
                    console.log(1);
                }
            })



                // $.ajax({
                //     type: 'POST',
                //     url:"main.py",
                //     contentType: 'application/json; charset=UTF-8',
                //     success:function(data){ //成功的话，得到消息
                //         addselect(data);
                //     },
                //     error:function (data) {
                //         // console.log(data);
                //
                //     }
                // });

    // $.ajax({
    //     url: "http://music.cccyun.cc/",
    //     type: "POST",
    //     dataType: "jsonp",//指定数据格式
    //     data: {
    //         input: '独家记忆',
    //         filter: 'name',
    //         type: 'netease',
    //         page: 1,
    //     },
    //
    //     beforeSend: function(request) {
    //         // request.setRequestHeader('User-Agent','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
    //         //     'Accept','application/json, text/javascript, */*; q=0.01',
    //         //     'Accept-Encoding','gzip, deflate',
    //         //     'Accept-Language','zh-CN,zh;q=0.9',
    //         //     'Connection','keep-alive',
    //         //     'Content-Type','application/x-www-form-urlencoded; charset=UTF-8',
    //         //     'Host','music.cccyun.cc',
    //         //     'Origin','http://music.cccyun.cc',
    //         //     'Referer','http://music.cccyun.cc/?name=%E4%B8%8D%E8%A6%81%E8%AF%B4%E8%AF%9D&type=netease',
    //         //     'X-Requested-With','XMLHttpRequest');
    //     },
    //     success: function (obj) {
    //         console.log(obj);
    //     },
    //     error: function (obj) {
    //         console.log(obj);
    //
    //     }
    // });
    // $(".submit").click(function () {
    //
    //     var searchname = $(".text").val();
    //     var val = $("input[name='music-select']:checked").val();
    //
    //     if(val == 163){
    //         var search163id = "http://api.bzqll.com/music/netease/search?key=579621905&s=" + searchname + "&limit=10";
    //         get163(search163id);
    //     }else if(val == 'qq'){
    //         var searchqqid = "http://api.bzqll.com/music/tencent/search?key=579621905&s=" + searchname + "&num=10&page=1";
    //         f(searchqqid);
    //     }
    //
    //
    //
    //
    // });
    //
    // var aa = 'https://api.bzqll.com/music/tencent/search?key=579621905&s=123&num=10&page=1';
    // function f(searchqqid) {
    //     $.ajax({
    //         url: searchqqid,
    //         type: "GET",
    //         dataType: "json",//指定数据格式
    //         success: function (obj3) {
    //             console.log(obj3);
    //
    //         },
    //         error: function (obj3) {
    //
    //             console.log(obj3);
    //         }
    //     });
    // }



    //播放
});
