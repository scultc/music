

import requests

def getMessage():
    url = 'http://music.cccyun.cc'
    data = {
        "input": search,
        "filter": 'name',
        "type": music_type,
        "page": 1,
    }
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Host': 'music.cccyun.cc',
        'Origin': 'http://music.cccyun.cc',
        'Referer': 'http://music.cccyun.cc/?name=%E4%B8%8D%E8%A6%81%E8%AF%B4%E8%AF%9D&type=netease',
        'X-Requested-With': 'XMLHttpRequest'
    }
    response = requests.post(url, data=data, headers=headers)
    result = response.text

    # print(type(response.text))
    # print()
    # print(response.text)
